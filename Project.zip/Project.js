let navbar = document.querySelector('.navbar');
document.querySelector('#menu-bar').onclick=() =>{
    navbar.classList.toggle('active');
}



let search = document.querySelector('.search');
document.querySelector('#search').onclick=() =>{
    search.classList.toggle('active');
}


var swiper = new Swiper(".product-row", {
    spaceBetween: 30,
    loop:true,
    centeredSlides:true,
    autoplay:{
        delay:9500,
        disableOnInteraction:false,
    },
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    breakpoints: {
      0: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 2,
      },
      1024: {
        slidesPerView: 3,
      },
    },
  });

  let valueDisplay = document.querySelectorAll('.num');
  let interval = 1000;

  valueDisplay.forEach((valueDisplay) => {
      let startValue=0;
      let endValue=parseInt(valueDisplay.getAttribute("data-value"));
      
      let duration = Math.floor(interval/endValue)
      let counter = setInterval (function (){
          startValue += 1;
          valueDisplay.textContent=startValue;
          if (startValue==endValue){
            clearInterval(counter);
          }
      }, duration );
  })

  

  function myFunction() {
    document.getElementById("myNumber").stepUp(1);
  }
  
  function myFunction() {
    alert("Thanks For Your Order");
    document.getElementById("form").reset();
  }
  